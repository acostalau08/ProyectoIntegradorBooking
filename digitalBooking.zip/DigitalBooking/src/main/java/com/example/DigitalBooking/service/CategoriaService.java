package com.example.DigitalBooking.service;

import org.springframework.stereotype.Service;

@Service
public class CategoriaService {

}
